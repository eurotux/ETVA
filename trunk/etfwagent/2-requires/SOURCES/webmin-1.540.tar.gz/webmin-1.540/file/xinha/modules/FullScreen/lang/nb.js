// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Maximize/Minimize Editor": "Maksimer/Minimer WYSIWYG vindu"
};