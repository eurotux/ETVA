#!/bin/bash

if [ ! -d "/etc/pki/CA" ]; then
	mkdir -p /etc/pki/CA;
fi

cp cakey.pem /etc/pki/CA/cakey.pem

cp cacert.pem /etc/pki/CA/cacert.pem

if [ ! -d "/etc/pki/libvirt" ]; then
	mkdir -p /etc/pki/libvirt/private;
fi

cp serverkey.pem /etc/pki/libvirt/private/serverkey.pem

cp servercert.pem /etc/pki/libvirt/servercert.pem

ln -s /etc/pki/libvirt/private/serverkey.pem /etc/pki/libvirt/private/clientkey.pem
ln -s /etc/pki/libvirt/servercert.pem /etc/pki/libvirt/clientcert.pem

