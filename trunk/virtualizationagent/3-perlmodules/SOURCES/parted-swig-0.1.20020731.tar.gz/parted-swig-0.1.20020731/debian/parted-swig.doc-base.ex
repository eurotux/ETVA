Document: parted-swig
Title: Debian parted-swig Manual
Author: <insert document author here>
Abstract: This manual describes what parted-swig is
 and how it can be used to
 manage online manuals on Debian systems.
Section: unknown

Format: debiandoc-sgml
Files: /usr/share/doc/parted-swig/parted-swig.sgml.gz

Format: postscript
Files: /usr/share/doc/parted-swig/parted-swig.ps.gz

Format: text
Files: /usr/share/doc/parted-swig/parted-swig.text.gz

Format: HTML
Index: /usr/share/doc/parted-swig/html/index.html
Files: /usr/share/doc/parted-swig/html/*.html

  
