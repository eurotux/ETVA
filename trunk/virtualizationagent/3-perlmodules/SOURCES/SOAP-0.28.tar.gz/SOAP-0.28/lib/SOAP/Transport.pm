package SOAP::Transport;
    
use strict;
use vars qw($VERSION);
$VERSION = '0.28';

# dummy module

1;
