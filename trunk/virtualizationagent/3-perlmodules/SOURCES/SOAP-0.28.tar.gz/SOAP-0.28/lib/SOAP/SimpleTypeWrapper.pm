package SOAP::SimpleTypeWrapper;

use strict;
use vars qw($VERSION);

$VERSION = '0.28';

1;
__END__

=head1 NAME

SOAP::SimpleTypeWrapper - deprecated

=head1 SYNOPSIS

deprecated

=head1 DESCRIPTION

Introduced in SOAP/Perl 0.24
Deprecated in SOAP/Perl 0.25

=head1 AUTHOR

Keith Brown

=cut




