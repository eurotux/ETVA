#define GLUSTERFS_REPOSITORY_REVISION "git://git.sv.gnu.org/gluster.git"
