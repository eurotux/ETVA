#!/bin/sh

export EDITOR="emacs"
git commit -a -e "$@"
