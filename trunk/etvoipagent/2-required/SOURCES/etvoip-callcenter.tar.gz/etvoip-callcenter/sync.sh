scp root@asterisk:/etc/asterisk/etux/* ./etc/asterisk/etux/
scp root@asterisk:/var/www/cgi-bin/* cgi-bin/
scp root@asterisk:/usr/local/sap2elastix/* sap2elastix/
scp -r root@asterisk:/var/www/html/static/* html/static/


